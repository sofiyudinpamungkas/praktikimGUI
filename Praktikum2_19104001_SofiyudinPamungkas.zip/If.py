x = False
y = True

# if..else
if x != True :
  print('print')
else :
  print('tidak print')

# If..else if..else
if x != False :
  print('print X')
elif y != False :
  print('print Y')

# if(..and..)..else
if x != True and y == False  :
  print('print')
else :
  print('tidak print')